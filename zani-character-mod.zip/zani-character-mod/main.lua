local MyCharacterMod = RegisterMod("Zani Character Mod", 1)

-- Zani (Wuthering Waves): the mysterious majordomo of the Montelli family.
-- Spectro-aligned, armed with a gauntlet that becomes a shield or a greatsword.
local zaniType = Isaac.GetPlayerTypeByName("Zani", false) -- Exactly as in the xml. The second argument is if you want the Tainted variant.
local TAINTED_ZANI_TYPE = Isaac.GetPlayerTypeByName("Zani", true) -- Tainted Zani (bSkin variant)
local hairCostume = Isaac.GetCostumeIdByPath("gfx/characters/zani_hair.anm2") -- Exact path, with the "resources" folder as the root
local coatCostume = Isaac.GetCostumeIdByPath("gfx/characters/zani_coat.anm2") -- Exact path, with the "resources" folder as the root

Isaac.DebugString("[ZaniMod] player types -> Zani: " .. tostring(zaniType) .. ", Tainted Zani: " .. tostring(TAINTED_ZANI_TYPE))
Isaac.DebugString("[ZaniMod] costume ids -> hair: " .. tostring(hairCostume) .. ", coat: " .. tostring(coatCostume))

function MyCharacterMod:GiveCostumesOnInit(player)
    local ptype = player:GetPlayerType()
    if ptype ~= zaniType and ptype ~= TAINTED_ZANI_TYPE then
        return -- End the function early. The below code doesn't run, as long as the player isn't Zani or Tainted Zani.
    end

    player:AddNullCostume(hairCostume)
    player:AddNullCostume(coatCostume)
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MyCharacterMod.GiveCostumesOnInit)


--------------------------------------------------------------------------------------------------


local game = Game() -- We only need to get the game object once. It's good forever!
local DAMAGE_BONUS = 1.0



--------------------------------------------------------------------------------------------------
-- Zani's Watch active item:
--   * Normal Zani starts with it in the PRIMARY slot (4 charges).
--   * Tainted Zani carries the same watch in the SECONDARY slot.
--   * On use: damage x1.5, and damage taken is halved (half-heart hits).
--   * The effect lasts for the current room only; it is cleared on room change.
--
--  IMPORTANT (fix): the item id must NOT be resolved at the top of the file.
--  content/items.xml may not be fully parsed when main.lua first runs, so
--  Isaac.GetItemIdByName(...) at load time can return -1, which made every
--  grant attempt (and the MC_USE_ITEM registration) silently fail.
--  We now resolve lazily on first use and cache the result.
--------------------------------------------------------------------------------------------------

local WATCH_ITEM_NAME = "Zani's Watch"
local ZANI_BUFF_MULT = 1.5

-- Buff state lives in a module-level table: player:GetData() is missing in
-- this patched (non-standard) Lua API environment, so it must not be used.
-- SINGLE shared state: the MC_USE_ITEM callback in this engine hands back a
-- player object WITHOUT GetPlayerType, so keying the state by player type
-- crashed exactly there (no anim, no buff). One Zani / one Tainted Zani per
-- run is assumed; all callbacks read/write the same table.
local zaniBuffState = { active = false, baseDamage = nil, baseDmg = nil }

local function getWatchState(player)
    return zaniBuffState
end

--- Zani's innate +1.0 damage.
--- EVALUATE_CACHE never fires in this patched environment, and a one-time
--- grant at game start gets wiped by the engine's own cache rebuild, so we
--- capture the born damage and enforce a floor every frame while the buff is
--- NOT active. This keeps +1.0 stable without blocking later damage pickups.
function MyCharacterMod:ApplyStartingStats(player)
    if player:GetPlayerType() ~= zaniType then
        return
    end
    local st = getWatchState(player)
    if not st.baseDmg then
        st.baseDmg = player.Damage
    end
    if st.active then
        return -- buff active: ApplyZaniBuff locks the 1.5x multiplier
    end
    player.Damage = math.max(player.Damage, st.baseDmg + DAMAGE_BONUS)
end

local watchIdResolved = false
local cachedWatchId = nil

--- Resolve the custom active item id lazily and cache it.
--- Returns nil while unknown, or the item id (>0) once items.xml has registered it.
function MyCharacterMod:GetZaniWatchId()
    if watchIdResolved then
        return cachedWatchId
    end

    watchIdResolved = true
    cachedWatchId = Isaac.GetItemIdByName(WATCH_ITEM_NAME)
    if cachedWatchId == nil or cachedWatchId == -1 then
        Isaac.DebugString("[ZaniMod] ERROR: could not resolve item id for " .. WATCH_ITEM_NAME)
    else
        Isaac.DebugString("[ZaniMod] resolved " .. WATCH_ITEM_NAME .. " id: " .. tostring(cachedWatchId))
    end
    return cachedWatchId
end

--- Try to place the watch into the POCKET slot (bottom-right HUD slot, the
--- card/pill/trinket position). This is where most Tainted characters keep
--- their birth active item, and it is what the user means by "副手".
--- This patched engine's bindings (resources/scripts/main.lua) are NON-STANDARD:
---   * player:AddCollectible(id, charge, addConsumables, activeSlot, varData, pool)
---     accepts an ActiveSlot as 4th argument -> can grant straight into POCKET.
---   * player:SetPocketActiveItem(id, slot, keepInPools) -- 2nd arg is the
---     ActiveSlot (number), NOT the standard "active" boolean. Passing true
---     throws "number expected, got boolean".
--- All attempts run under pcall protection.
--- Returns true on success.
function MyCharacterMod:MoveWatchToPocket(player, itemId)
    -- This engine's SetPocketActiveItem(id, SLOT_POCKET) EQUIPS the pocket
    -- slot directly; it does NOT move an item out of PRIMARY. AddCollectible
    -- into PRIMARY first produced a duplicate (watch in BOTH slots), so the
    -- pocket slot is set on its own here.
    local okSet, errSet = pcall(function()
        player:SetPocketActiveItem(itemId, ActiveSlot.SLOT_POCKET)
        if player.SetActiveCharge then
            player:SetActiveCharge(4, ActiveSlot.SLOT_POCKET)
        end
    end)
    if okSet then
        Isaac.DebugString("[ZaniMod] MOVED " .. WATCH_ITEM_NAME .. " to POCKET via SetPocketActiveItem(slot=POCKET)")
        return true
    end

    -- Fallback: grant into PRIMARY so the item is at least usable.
    local okGrant, errGrant = pcall(function()
        player:AddCollectible(itemId, 4, false)
    end)
    Isaac.DebugString("[ZaniMod] SetPocketActiveItem failed (" .. tostring(errSet) .. "); fallback AddCollectible=" .. tostring(okGrant) .. (errGrant and (" (" .. tostring(errGrant) .. ")") or ""))
    return okGrant
end

--- One-shot success flag per player (keyed by InitSeed, stable for the run).
--- Stops the endless pedestal loop: without it the tainted path re-grants the
--- watch every frame because GetActiveItem(SLOT_PRIMARY) never reports 806
--- after the pocket relocation.
local watchGrantedOnce = {}

--- Grant the watch if it is not already owned (either slot).
function MyCharacterMod:GrantZaniWatch(player)
    local ptype = player:GetPlayerType()
    local isTainted = (ptype == TAINTED_ZANI_TYPE)
    if ptype ~= zaniType and not isTainted then
        return
    end

    local key = player.InitSeed
    if key == nil then
        key = tostring(player)
    end
    if watchGrantedOnce[key] then
        return -- already granted successfully, never re-grant
    end

    local itemId = MyCharacterMod:GetZaniWatchId()
    if not (itemId and itemId > 0) then
        Isaac.DebugString("[ZaniMod] SKIP grant: " .. WATCH_ITEM_NAME .. " id not resolved yet (player type " .. tostring(ptype) .. ")")
        return
    end

    local primary = player:GetActiveItem(ActiveSlot.SLOT_PRIMARY)

    -- Check the POCKET slot too (the "副手" position). GetPocketActiveItem may
    -- not exist in this patched engine, so guard it with pcall.
    local pocketHas = false
    if player.GetPocketActiveItem then
        pocketHas = pcall(function() return player:GetPocketActiveItem() == itemId end)
    end

    if primary == itemId or pocketHas then
        -- Tainted Zani: if the watch is in PRIMARY, try to move it to POCKET.
        if isTainted and primary == itemId and not pocketHas then
            MyCharacterMod:MoveWatchToPocket(player, itemId)
        end
        watchGrantedOnce[key] = true
        return
    end

    -- Grant. Tainted Zani gets the watch in the POCKET slot.
    if isTainted then
        local ok = MyCharacterMod:MoveWatchToPocket(player, itemId)
        Isaac.DebugString("[ZaniMod] GRANTED " .. WATCH_ITEM_NAME .. " (id=" .. tostring(itemId) .. ") to player type " .. tostring(ptype) .. " via POCKET path")
        if ok then
            watchGrantedOnce[key] = true
        end
    else
        player:AddCollectible(itemId, 4, false)
        local pool = game:GetItemPool()
        pool:RemoveCollectible(itemId)
        Isaac.DebugString("[ZaniMod] GRANTED " .. WATCH_ITEM_NAME .. " (id=" .. tostring(itemId) .. ") to player type " .. tostring(ptype) .. " in PRIMARY")
        watchGrantedOnce[key] = true
    end
end

--- Grant at birth (PRIMARY for Zani, SECONDARY for Tainted Zani).
function MyCharacterMod:InitZaniActiveItem(player)
    MyCharacterMod:GrantZaniWatch(player)
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MyCharacterMod.InitZaniActiveItem)

--- Safety net: re-check on game start so the item is always granted even if the
--- birth callback ran before the active slot was fully initialized.
function MyCharacterMod:InitZaniActiveItemGameStart()
    for i = 0, game:GetNumPlayers() - 1 do
        local player = Isaac.GetPlayer(i)
        MyCharacterMod:GrantZaniWatch(player)
    end

    -- One-shot API probe: log which relevant player methods this patched
    -- engine actually exposes. Helps diagnose slot/pocket issues.
    if not MyCharacterMod.apiProbeDone then
        MyCharacterMod.apiProbeDone = true
        local player = Isaac.GetPlayer(0)
        local probe = {
            "SetActiveItem", "SetPocketActiveItem", "AddPocketItem",
            "GetPocketActiveItem", "SetPocketActiveCharge", "GetPocketActiveCharge",
            "SetActiveCharge", "GetActiveItem",
        }
        for _, m in ipairs(probe) do
            Isaac.DebugString("[ZaniMod] API " .. m .. " = " .. tostring(player[m] ~= nil))
        end
    end
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, MyCharacterMod.InitZaniActiveItemGameStart)

--- Extra safety net: keep trying for the first 120 frames after game start.
--- Covers any remaining timing edge case (item id registered late, slot init
--- order, character select -> run transition) without running forever.
local WATCH_GRANT_CHECK_FRAMES = 120
local WATCH_GRANT_INTERVAL = 5

function MyCharacterMod:WatchGrantSafetyNet(player)
    local frame = game:GetFrameCount()
    if frame <= WATCH_GRANT_CHECK_FRAMES and frame % WATCH_GRANT_INTERVAL == 0 then
        local ptype = player:GetPlayerType()
        if ptype == zaniType or ptype == TAINTED_ZANI_TYPE then
            MyCharacterMod:GrantZaniWatch(player)
        end
    end

    -- One-shot probe: confirm the per-frame hook really ticks in this engine.
    if not MyCharacterMod.peffectTickLogged then
        MyCharacterMod.peffectTickLogged = true
        Isaac.DebugString("[ZaniMod] PEFFECT_UPDATE tick alive, player.Damage=" .. tostring(player.Damage))
    end

    -- Every-frame damage override: AddCacheFlags/EVALUATE_CACHE are missing in
    -- this patched environment, so the +1.0 floor and the 1.5x buff must be
    -- enforced here.
    MyCharacterMod:ApplyStartingStats(player)
    MyCharacterMod:ApplyZaniBuff(player)
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MyCharacterMod.WatchGrantSafetyNet)

--- Second per-frame hook (MC_POST_PLAYER_UPDATE) as a belt-and-suspenders:
--- if the patched engine never fires PEFFECT_UPDATE, this still enforces the
--- +1.0 floor and the 1.5x buff. Both hooks are idempotent, so double firing
--- is harmless.
function MyCharacterMod:PlayerTickBuff(player)
    local ptype = player:GetPlayerType()
    if ptype ~= zaniType and ptype ~= TAINTED_ZANI_TYPE then
        return
    end
    MyCharacterMod:ApplyStartingStats(player)
    MyCharacterMod:ApplyZaniBuff(player)
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, MyCharacterMod.PlayerTickBuff)

--- Registered WITHOUT a third argument so it fires for every active item use;
--- we match the id inside the callback. This is immune to id-resolution timing.
function MyCharacterMod:ZaniWatchUse(item, player, useFlags, activeSlot, varData)
    local itemId = MyCharacterMod:GetZaniWatchId()
    -- Probe: log EVERY use plus the Lua types of both ids. This patched engine
    -- passes the item id to MC_USE_ITEM as a STRING in some builds; a strict
    -- number comparison then silently rejects the watch (no buff, no anim).
    Isaac.DebugString("[ZaniMod] USE_ITEM fired item=" .. tostring(item) .. " itemType=" .. type(item) .. " watchId=" .. tostring(itemId) .. " watchType=" .. type(itemId) .. " slot=" .. tostring(activeSlot))
    local usedItem = tonumber(item)
    if usedItem == nil or usedItem ~= itemId then
        return false
    end

    -- Wind the watch: lock the damage to 1.5x its value BEFORE the buff takes
    -- effect. The player object in this callback lacks GetPlayerType; every
    -- access is pcall-guarded.
    local st = getWatchState(player)
    if not st.baseDamage then
        local ok, dmg = pcall(function() return player.Damage end)
        if ok and dmg then
            st.baseDamage = dmg
        end
    end
    st.active = true

    Isaac.DebugString("[ZaniMod] " .. WATCH_ITEM_NAME .. " used (id=" .. tostring(itemId) .. "), buff active")
    return true
end

MyCharacterMod:AddCallback(ModCallbacks.MC_USE_ITEM, MyCharacterMod.ZaniWatchUse)

--- Apply the 1.5x multiplier while the buff is active (called every frame).
function MyCharacterMod:ApplyZaniBuff(player)
    local st = getWatchState(player)
    if st.active then
        -- Fallback capture: if the use callback could not read player.Damage,
        -- grab it on the first per-frame tick instead.
        if not st.baseDamage then
            local ok, dmg = pcall(function() return player.Damage end)
            if ok and dmg then
                st.baseDamage = dmg
            end
        end
        if st.baseDamage then
            -- Fixed 1.5x multiplier based on the damage value captured on use.
            player.Damage = st.baseDamage * ZANI_BUFF_MULT
            -- Throttled diagnostic: log the applied damage at most every 30
            -- frames so a single test run shows whether the buff is landing.
            local frame = game:GetFrameCount()
            if not MyCharacterMod.buffLogFrame or (frame - MyCharacterMod.buffLogFrame) >= 30 then
                MyCharacterMod.buffLogFrame = frame
                Isaac.DebugString("[ZaniMod] BUFF frame=" .. tostring(frame) .. " Damage=" .. tostring(player.Damage) .. " base=" .. tostring(st.baseDamage))
            end
        end
    end
end

--- While the buff is active, incoming damage is capped at half a heart.
--- (Wafer-style: 直接改写伤害数值而不是 cancel+手动补伤。)
---
--- 实现说明：圣饼(Wafer)本体逻辑在引擎 C++ 内部，Lua 层看不到也无法调用。
--- 官方 Lua 对 MC_ENTITY_TAKE_DMG 只认"return false 取消"，不支持改伤害值；
--- REPENTOGON/增强 API 协议则允许返回 { Damage=... }，引擎会按新数值继续
--- 走正常结算 —— 伤害事件不取消，献祭计数 / 受击无敌帧 / 受击动画全部由
--- 引擎自己保留，这正是"圣饼式"行为。当前 patched 引擎是否实现该协议，
--- 需实机验证：若踩献祭刺只扣半心且计数增加 → 生效；若仍扣满额 → 不支持。
function MyCharacterMod:OnEntityTakeDmg(entity, amount, flags, source, countdownFrames)
    if entity.Type ~= EntityType.ENTITY_PLAYER then
        return
    end

    local ptype = entity.SubType
    if ptype ~= zaniType and ptype ~= TAINTED_ZANI_TYPE then
        return
    end

    local st = getWatchState(entity)
    Isaac.DebugString("[ZaniMod] TakeDmg type=" .. tostring(ptype) .. " amount=" .. tostring(amount) .. " flags=" .. tostring(flags) .. " active=" .. tostring(st.active or false))
    if not st.active then
        return
    end

    -- 引擎以 DAMAGE_NO_MODIFIERS 标记"不应受圣饼这类伤害修饰影响"的伤害
    -- （恶魔交易、诅咒门代价等），与圣饼一致：这类伤害不干预，直接放行。
    if flags & DamageFlag.DAMAGE_NO_MODIFIERS ~= 0 then
        return
    end

    -- 圣饼式封顶：受到的伤害最多为半心（amount=1.0 视为一颗心，半心=0.5）。
    -- 献祭房地刺(SPIKES, amount>=2.0)不再特殊放行：数值改写后伤害事件依然
    -- 由引擎正常结算，献祭计数应照常增加，同时只扣半心。
    local newAmount = math.min(amount, 0.5)

    Isaac.DebugString("[ZaniMod] DMG_REWRITE original=" .. tostring(amount) .. " -> half=" .. tostring(newAmount))
    return { Damage = newAmount }
end

MyCharacterMod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, MyCharacterMod.OnEntityTakeDmg)

--- Leaving the room clears the buff, restores the pre-buff damage and lets
--- the +1.0 floor take over again.
function MyCharacterMod:OnNewRoom()
    for i = 0, game:GetNumPlayers() - 1 do
        local player = Isaac.GetPlayer(i)
        local ptype = player:GetPlayerType()
        if ptype == zaniType or ptype == TAINTED_ZANI_TYPE then
            local st = getWatchState(player)
            if st.active then
                if st.baseDamage then
                    player.Damage = st.baseDamage
                end
                st.active = false
                st.baseDamage = nil
            end
        end
    end
end

MyCharacterMod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, MyCharacterMod.OnNewRoom)
