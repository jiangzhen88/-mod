---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 22500409903e44c99b21e631dde582d5_b82f25b1a57811f1a0d9525400826444
    ReservedCode1: hf7RnkjHxmplxKS+pE5mzo4e8eEeF03m9utdmHlDF4TBrqALLQRpe2ml2uyZKrjZAafdOe0psVM0tRMc84gQ6/CiScyxN5HMros3GTSyltejOPDa2y5EUFKqvm0gn+pojHA4JxmfXwrynnRDINr94FgMQnMF1BgD8A2bAMsOJvZYbMcE8HoUNvVcA2Y=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 22500409903e44c99b21e631dde582d5_b82f25b1a57811f1a0d9525400826444
    ReservedCode2: hf7RnkjHxmplxKS+pE5mzo4e8eEeF03m9utdmHlDF4TBrqALLQRpe2ml2uyZKrjZAafdOe0psVM0tRMc84gQ6/CiScyxN5HMros3GTSyltejOPDa2y5EUFKqvm0gn+pojHA4JxmfXwrynnRDINr94FgMQnMF1BgD8A2bAMsOJvZYbMcE8HoUNvVcA2Y=
---

# Zani Character Mod (The Binding of Isaac: Repentance)

以撒的结合：忏悔 人物模组 —— 鸣潮（Wuthering Waves）角色「赞妮」（Zani）。

## 角色设定

- **赞妮（Zani）**：鸣潮黎那汐塔·拉古那地区的角色，埃弗拉德银行精英。白发、红瞳、头顶黑色恶魔弯角，黑色风衣 + 白衬衫 + 亮红领带。
- **属性**：衍射（Spectro）系输出型角色，武器为可化盾化剑的臂铠。
- **初始属性**：4 颗红心、2 颗护甲、1 把钥匙，伤害 +0.6（取材自模板默认数值，可在 main.lua 的 `DAMAGE_BONUS` 调整）。
- **专属机制（光耀灼痕）**：赞妮移动时会在身后留下淡金色衍射灼痕（小范围圣水轨迹效果），持续灼烧敌人。
- **专属道具（Zani's Watch）**：里角色「里赞妮」初始携带的怀表主动道具，激活后在前方地面制造大范围衍射灼痕区域。
- **里角色（Tainted Zani）**：深色变体，自带专属主动道具，可无限重随前先移除道具池。

## 模组结构

```
zani-character-mod/
├── main.lua                     # 角色注册、属性、服装、灼痕机制、里角色逻辑
├── content/
│   ├── players.xml              # 角色定义（赞妮 / 里赞妮）
│   ├── items.xml                # 专属道具 Zani's Watch
│   ├── costumes2.xml            # 空服装（白发 + 黑风衣红领带）
│   └── gfx/                     # 菜单/立绘/死亡/控制界面 anm2 + png
└── resources/
    └── gfx/
        ├── characters/
        │   ├── zani_hair.anm2   # 白发（含黑色恶魔角）动画
        │   ├── zani_coat.anm2   # 黑风衣红领带动画
        │   └── costumes/
        │       ├── character_zani.png      # 角色底模
        │       ├── character_zani_b.png    # 里角色底模
        │       ├── zani hair.png           # 白发 + 黑角贴图
        │       └── zani body.png           # 黑风衣红领带贴图
        ├── items/collectibles/zani_watch.png  # 道具图标（金色怀表）
        └── ui/                    # 名字图、立绘
```

## 安装方式

1. **备份存档**：运行游戏前建议备份 `C:\Users\<用户名>\Documents\My Games\Binding of Isaac Repentance+` 下的存档。
2. **放置模组**：将整个 `zani-character-mod` 文件夹复制到以撒的 Mods 目录：
   - Steam 版：`Steam\steamapps\common\The Binding of Isaac Rebirth\mods\`
   - 或使用创意工坊外的本地 mods 目录后，在游戏内 Mods 菜单勾选启用。
3. **启用模组**：启动游戏 → Options → Mods → 勾选「Zani Character Mod」。
4. **选择角色**：开始新游戏时在角色选择界面选择 **Zani**（赞妮）或按住 Tab 选择 **Tainted Zani**（里赞妮）。

## 二次开发提示

- 修改数值：`main.lua` 顶部的 `DAMAGE_BONUS`、`players.xml` 中的 `hp` / `armor` / `keys`。
- 更换立绘：替换 `resources/gfx/ui/stage/playerportrait_zani.png`（144x144）。
- 更换名字图：`resources/gfx/ui/boss/playername_zani.png`（192x64）。
- 模板注意：`content/gfx` 下的 .anm2 文件名不可更改，仅可改内部引用。
*（内容由AI生成，仅供参考）*
